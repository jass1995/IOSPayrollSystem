//
//  Pay.swift
//  PayrollSystem
//
//  Created by MacStudent on 2018-08-17.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

struct ElectricityBill
{
    var Empname: String?
    var EmpType:String?
    var birthdate : Date?
    var have:String?
    var Vtype:String?
    var Plate:String?
    var Model:String?
    var total:Double?
    
}
