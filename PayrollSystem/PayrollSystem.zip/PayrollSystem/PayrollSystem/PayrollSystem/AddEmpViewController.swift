//
//  AddEmpViewController.swift
//  PayrollSystem
//
//  Created by MacStudent on 2018-08-16.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class AddEmpViewController: UIViewController {

    @IBOutlet weak var empname: UITextField!
    @IBOutlet weak var picker: UIDatePicker!
    @IBOutlet weak var txtmodel: UITextField!
    @IBOutlet weak var txtplatenum: UITextField!
    @IBOutlet weak var HaveVehicle: UISwitch!
    @IBOutlet weak var mbtype: UISegmentedControl!
    @IBOutlet weak var empTypeSeg: UISegmentedControl!
    @IBOutlet weak var txthourRate: UITextField!
    @IBOutlet weak var comisionfixSeg: UISegmentedControl!
    @IBOutlet weak var NoOfHours: UITextField!
    @IBOutlet weak var txtRate: UITextField!
    @IBOutlet weak var txtbonus: UITextField!
    @IBOutlet weak var txtsalary: UITextField!
    @IBOutlet weak var txtSchool: UITextField!
    @IBOutlet weak var txtFixed: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        HaveVehicle.isOn = false
        mbtype.isHidden = true
        txtmodel.isHidden = true
        txtplatenum.isHidden = true
        empTypeSeg.selectedSegmentIndex = 0
        txthourRate.isHidden = false
        NoOfHours.isHidden = false
        comisionfixSeg.isHidden = false
        txtsalary.isHidden = true
        txtbonus.isHidden = true
        txtSchool.isHidden = true
        txtRate.isHidden = false
        // Do any additional setup after loading the view.
    }

    @IBAction func HaveVehicleAction(_ sender: UISwitch) {
        
        if sender.isOn
        {
         mbtype.isHidden = false
        txtmodel.isHidden = false
        txtplatenum.isHidden = false
        }
        else
        {
          mbtype.isHidden = true
            txtmodel.isHidden = true
            txtplatenum.isHidden = true
        }
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func Vehicletype(_ sender: UISwitch) {
      
        
    }
        
    @IBAction func empTypeSegmentation(_ sender: Any) {
        
        if(empTypeSeg.selectedSegmentIndex == 0)
      {
        txthourRate.isHidden = false
        NoOfHours.isHidden = false
        comisionfixSeg.isHidden = false
        txtsalary.isHidden = true
        txtbonus.isHidden = true
        txtSchool.isHidden = true
        txtRate.isHidden = false
        } else if(empTypeSeg.selectedSegmentIndex == 1)
        {
            txthourRate.isHidden = true
            NoOfHours.isHidden = true
            comisionfixSeg.isHidden = true
            txtsalary.isHidden = false
            txtbonus.isHidden = false
            txtSchool.isHidden = true
            txtRate.isHidden = true
            txtFixed.isHidden = true
            
        } else if(empTypeSeg.selectedSegmentIndex == 2)
        {
            txthourRate.isHidden = true
            NoOfHours.isHidden = true
            comisionfixSeg.isHidden = true
            txtsalary.isHidden = true
            txtbonus.isHidden = true
            txtSchool.isHidden = false
            txtRate.isHidden = true
            txtFixed.isHidden = true
        }
        
    }
    
    @IBAction func comfixAction(_ sender: Any) {
        
        if(comisionfixSeg.selectedSegmentIndex == 0)
        {
            txtRate.isHidden = false
            txtFixed.isHidden=true
        }else
        {
            txtRate.isHidden = true
            txtFixed.isHidden = false
        }
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
